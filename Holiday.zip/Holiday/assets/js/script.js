// URLs y credenciales
const apiUrl = 'https://hie-3f29.onrender.com/api/employees';
const authUrl = 'https://hie-3f29.onrender.com/auth/login';

// Obtener token de autenticación
async function getAuthToken() {
  try {
    const response = await fetch(authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userCredentials)
    });

    if (!response.ok) throw new Error('Error al autenticar');
    const data = await response.json();
    localStorage.setItem('authToken', data.token);
    return data.token;
  } catch (error) {
    console.error(error);
    return null;
  }
}

function getStoredToken() {
  return localStorage.getItem('authToken');
}

// Obtener empleados
async function fetchEmployees(page = 1, search = '', limit = 10) {
  const token = getStoredToken() || await getAuthToken();
  if (!token) return;

  try {
    const response = await fetch(`${apiUrl}?page=${page}&limit=${limit}&searchTerm=${search}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!response.ok) throw new Error('Error al obtener empleados');
    const employees = await response.json();
    renderEmployees(employees);
  } catch (error) {
    console.error(error);
  }
}

// Renderizar empleados en la tabla
function renderEmployees(employees) {
  const tableBody = document.querySelector('#employeeTable tbody');
  tableBody.innerHTML = '';

  if (!employees || employees.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="5">No hay empleados para mostrar</td></tr>';
    return;
  }

  employees.forEach(employee => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${employee.id_employee}</td>
      <td>${employee.employeeName}</td>
      <td>${employee.department}</td>
      <td>${employee.status || 'Activo'}</td>
      <td style="display: flex;">
         <button onclick="viewEmployee(${employee.id_employee})">
      <img src="assets/img/eye.svg" alt="Ver" style="width: 24px; height: 24px;">
    </button>
    <button onclick="editEmployee(${employee.id_employee})">
      <img src="assets/img/calendar.svg" alt="Editar" style="width: 24px; height: 24px;">
    </button>
    <button onclick="deleteEmployee(${employee.id_employee})">
      <img src="assets/img/trash.svg" alt="Eliminar" style="width: 24px; height: 24px;">
    </button>
      </td>
    `;
    tableBody.appendChild(row);
  });
}

// Crear empleado
async function createEmployee() {
  const token = getStoredToken() || await getAuthToken();
  if (!token) return;

  const employeeData = {
    employeeName: document.getElementById('employeeName').value,
    email: document.getElementById('email').value,
    department: document.getElementById('department').value,
    phoneNumber: document.getElementById('phoneNumber').value,
    address: document.getElementById('address').value
  };

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(employeeData)
    });

    if (response.ok) {
      alert('Empleado creado correctamente');
      closeCreateModal();
      fetchEmployees();
    } else {
      alert('Error al crear empleado');
    }
  } catch (error) {
    console.error(error);
  }
}

// Editar empleado
async function editEmployee(employeeId) {
  const token = getStoredToken() || await getAuthToken();
  if (!token) return;

  try {
    const response = await fetch(`${apiUrl}/${employeeId}`, {
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!response.ok) throw new Error('Error al cargar empleado');
    const employee = await response.json();

    // Rellenar el formulario
    document.getElementById('employeeName').value = employee.employeeName;
    document.getElementById('email').value = employee.email;
    document.getElementById('department').value = employee.department;
    document.getElementById('phoneNumber').value = employee.phoneNumber;
    document.getElementById('address').value = employee.address;

    // Cambiar el botón
    const saveButton = document.querySelector('#createEmployeeForm button');
    saveButton.textContent = 'Actualizar';
    saveButton.onclick = () => updateEmployee(employeeId);

    openCreateModal();
  } catch (error) {
    console.error(error);
  }
}

// Actualizar empleado
async function updateEmployee(employeeId) {
  const token = getStoredToken() || await getAuthToken();
  if (!token) return;

  const updatedData = {
    employeeName: document.getElementById('employeeName').value,
    email: document.getElementById('email').value,
    department: document.getElementById('department').value,
    phoneNumber: document.getElementById('phoneNumber').value,
    address: document.getElementById('address').value
  };

  try {
    const response = await fetch(`${apiUrl}/${employeeId}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(updatedData)
    });

    if (response.ok) {
      alert('Empleado actualizado correctamente');
      closeCreateModal();
      fetchEmployees();
    } else {
      alert('Error al actualizar empleado');
    }
  } catch (error) {
    console.error(error);
  }
}

// Eliminar empleado
async function deleteEmployee(employeeId) {
  const token = getStoredToken() || await getAuthToken();
  if (!token) return;

  if (!confirm('¿Seguro que deseas eliminar este empleado?')) return;

  try {
    const response = await fetch(`${apiUrl}/${employeeId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (response.ok) {
      alert('Empleado eliminado');
      fetchEmployees();
    } else {
      alert('Error al eliminar empleado');
    }
  } catch (error) {
    console.error(error);
  }
}

// Abrir modal
function openCreateModal() {
  document.getElementById('createEmployeeModal').style.display = 'flex';
}

// Cerrar modal
function closeCreateModal() {
  document.getElementById('createEmployeeModal').style.display = 'none';
}

// Buscar empleados
function searchEmployees() {
  const searchQuery = document.getElementById('search').value;
  fetchEmployees(1, searchQuery);
}

// Inicializar
document.addEventListener('DOMContentLoaded', fetchEmployees);
